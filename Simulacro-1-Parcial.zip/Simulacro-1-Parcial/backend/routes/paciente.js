const express = require("express");
const router = express.Router();
const Paciente = require("../models/pacienteModel");
const { Op, ValidationError } = require("sequelize");

// GET con filtros y paginación
router.get("/", async (req, res) => {
    const { propietario, pagina } = req.query;
    const tamañoPagina = 10;
    const paginaActual = parseInt(pagina) || 1;
    const offset = (paginaActual - 1) * tamañoPagina;

    try {
        const whereCondition = propietario ? {
            Propietario: {
                [Op.like]: `%${propietario}%`
            }
        } : {};

        const { count, rows } = await Paciente.findAndCountAll({
            where: whereCondition,
            order: [["NombreMascota", "ASC"]],
            limit: tamañoPagina,
            offset
        });

        return res.json({
            Items: rows,
            RegistrosTotal: count,
            PaginaActual: paginaActual,
            TotalPaginas: Math.ceil(count / tamañoPagina)
        });
    } catch (error) {
        console.error("💥 ERROR en GET /api/pacientes:", error); // 👈 NUEVO
        res.status(500).json({ error: "Error al obtener pacientes" });
    }
});

// GET por ID
router.get("/:id", async (req, res) => {
    try {
        const paciente = await Paciente.findByPk(req.params.id);
        paciente ? res.json(paciente) : res.status(404).json({ error: "Paciente no encontrado" });
    } catch (error) {
        res.status(500).json({ error: "Error al buscar paciente" });
    }
});

// POST nuevo paciente
router.post("/", async (req, res) => {
    try {
        const nuevo = await Paciente.create(req.body);
        res.status(201).json(nuevo);
    } catch (error) {
        if (error instanceof ValidationError) {
            let msg = error.errors.map(e => `${e.path}: ${e.message}`).join('\n');
            res.status(400).json({ message: msg });
        } else {
            res.status(500).json({ error: "Error al crear paciente" });
        }
    }
});

// PUT actualizar paciente
router.put("/:id", async (req, res) => {
    try {
        const paciente = await Paciente.findByPk(req.params.id);
        if (!paciente) return res.status(404).json({ error: "Paciente no encontrado" });

        await paciente.update(req.body);
        res.status(204).end();
    } catch (error) {
        if (error instanceof ValidationError) {
            let msg = error.errors.map(e => `${e.path}: ${e.message}`).join('\n');
            res.status(400).json({ message: msg });
        } else {
            res.status(500).json({ error: "Error al actualizar paciente" });
        }
    }
});

// DELETE paciente
router.delete("/:id", async (req, res) => {
    try {
        const eliminado = await Paciente.destroy({ where: { IdPaciente: req.params.id } });
        eliminado
            ? res.status(200).json({ mensaje: "Paciente eliminado" })
            : res.status(404).json({ error: "Paciente no encontrado" });
    } catch (error) {
        res.status(500).json({ error: "Error al eliminar paciente" });
    }
});

module.exports = router;
